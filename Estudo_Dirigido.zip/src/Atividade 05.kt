import kotlin.math.sqrt

fun main(){
    println("Informe o valor de A:")
    var a = readLine()!!.toFloat()
    println("Informe o valor de B:")
    var b = readLine()!!.toFloat()
    println("Informe o valor de C:")
    var c = readLine()!!.toFloat()

    var delta = (b * b) - (4 * a * c)
    var x1 = (-b + sqrt(delta)) / (2*a)
    var x2 = (-b - sqrt(delta)) / (2*a)

    if(delta > 0){
        println("O valor de X1 é $x1")
        println("O valor de X2 é $x2")
    }else if(delta < 0){
        println("A equação não possui raizes reais")
    }else{
        println("A equação possui apenas uma raiz sendo $x1")
    }
}
