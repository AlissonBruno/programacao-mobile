class Cachorro(pNome: String, pIdade: Int){
    private var nome = pNome
    private var idade = pIdade

    fun latir(){
        println("$nome esta Lantindo")
    }

    fun correr(){
        println("$nome esta Correndo")
    }

    fun passear(){
        println("$nome esta Passeando\n")
    }
}


fun main(){
    var dog1 = Cachorro("Rex",6)

    var dog2 = Cachorro("Neguinho",15)

    var dog3 = Cachorro("Pelota",10)

    dog1.correr()
    dog1.latir()
    dog1.passear()

    dog2.correr()
    dog2.latir()
    dog2.passear()

    dog3.correr()
    dog3.latir()
    dog3.passear()
}