fun main(){
    println("Insira um valor de 4 digitos:")
    var valor = readLine()!!.toInt()
    var primeira = valor/100
    var segunda = (valor%1000)%100
    println("Primeira Dezena = $primeira \n Segunda Dezena = $segunda")
}