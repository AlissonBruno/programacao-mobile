fun main(){
    println("Informe uma palavra para verificar se ela é um palindromo")
    var str1 : String = readLine().toString()
    var str2 = str1.reversed()

    if(str1.equals(str2)){
        print("$str1 é um Palindromo")
    }else{
        println("$str2 não é Palindromo")
    }
}