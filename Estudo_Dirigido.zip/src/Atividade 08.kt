fun main(){
    println("Informe uma palavra")
    var palavra = readLine()!!.toString()
    println("A palavra invertida é ${inverso(palavra)}")
}

fun inverso(texto:String): String{
    return texto.reversed()
}