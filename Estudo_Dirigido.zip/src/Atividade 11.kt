class ContaCorrente(pCliente: String,pAgencia: String,pNumConta: Int){
    private var cliente  = pCliente
    private var agencia  = pAgencia
    private var numConta = pNumConta
    private var saldo: Double = 0.0

    fun depositar(valor: Double): Double {
        saldo += valor
        return saldo
    }

    fun retirar(valor: Double): Double{
        saldo -= valor
        return saldo
    }

    fun transferir(pConta: ContaCorrente, pValor: Double){
        var conta: ContaCorrente  = pConta
        conta.saldo += pValor
        saldo -= pValor
    }

    fun extrato(){
        println("Cliente = $cliente")
        println("Agência = $agencia")
        println("Numero da conta = $numConta")
        println("Saldo = $saldo \n")
    }
}
fun main(){
    var ContaCorrente1 = ContaCorrente("Alisson","4577",5689)
    ContaCorrente1.depositar(1056.23)
    ContaCorrente1.retirar(467.56)

    var ContaCorrente2 = ContaCorrente("Jeovane","1560",3456)
    ContaCorrente2.depositar(3467.23)
    ContaCorrente2.retirar(236.56)
    ContaCorrente2.transferir(ContaCorrente1,100.0)

    var ContaCorrente3 = ContaCorrente("Pamela","4566",6789)
    ContaCorrente3.depositar(8765.23)
    ContaCorrente3.retirar(99.56)
    ContaCorrente3.transferir(ContaCorrente1,5000.0)

    ContaCorrente1.extrato()
    ContaCorrente2.extrato()
    ContaCorrente3.extrato()
}
