import jdk.nashorn.api.tree.ReturnTree
import kotlin.system.exitProcess

class Retangulo(pAltura: Int, pLargura: Int){
    private var altura  = pAltura
    private var largura = pLargura
    fun  desenhar(){
        for(x in 1..altura){
            for (y in 1..largura){
                print("* ")
            }
            print("\n")
        }
    }
    init {
        if((largura <= 0 || altura <= 0) || (largura > 20 || altura > 20)){
            println("Valores não atendem aos requisitos")
            exitProcess(0)
        }
    }
}


fun main(){
    println("Informe a altura do retangulo")
    var altura = readLine()!!.toInt()
    println("Informe a largura do retangulo")
    var largura = readLine()!!.toInt()
    Retangulo(altura,largura).desenhar()
}