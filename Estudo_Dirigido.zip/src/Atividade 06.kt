fun main(){
    println("Informer um valor para mudar o seu sinal")
    var valor = readLine()!!.toFloat()
    println("O vqlor com sinal alterado é ${sinal(valor)}")
}

fun sinal(x:Float): Float {
    return  x * -1
}