fun main(){
    val notas : IntArray = intArrayOf(0,1,2)
    val pesos : IntArray = intArrayOf(0,1,2)
    pesos[0] = 2
    pesos[1] = 3
    pesos[2] = 5
    for(x in 0..2){
        println("Insira a ${x + 1} º nota")
        notas[x] = readLine()!!.toInt()
    }
    var media = (((notas[0]*pesos[0]) + (notas[1]*pesos[1]) + (notas[2]*pesos[2])) / (pesos[0] + pesos[1] + pesos[2]).toFloat())
    println("A média ponderada é: $media")
}