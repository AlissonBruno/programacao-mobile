import jdk.nashorn.api.tree.ReturnTree
import kotlin.system.exitProcess

class Triangulo(pAltura: Int){
    private var altura  = pAltura
    fun  desenhar(){
        for(x in 1..altura){
            for (y in 1..x){
                print("* ")
            }
            print("\n")
        }
    }
    init {
        if(altura <= 0 || altura > 20){
            println("Valores não atendem aos requisitos")
            exitProcess(0)
        }
    }
}

fun main(){
    println("Informe a altura do triangulo")
    var altura = readLine()!!.toInt()
    Triangulo(altura).desenhar()
}