class Abajur {
    private var ligado: Boolean = false

    fun ligar() {
        ligado = true
        print("O abajur foi ligado\n")
    }

    fun desligar() {
        ligado = false
        print("O abajur foi desligado\n")
    }
}

fun main(){
    var abajur1 = Abajur().ligar()
    abajur1 = Abajur().desligar()

    var abajur2 = Abajur().ligar()
    abajur2 = Abajur().desligar()
}
